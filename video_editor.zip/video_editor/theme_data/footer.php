<section style="background: #f7f6f1">
   <div class="container moble-mar" style=" margin-top: 40px;" >
   	   <!-- <div class="col-md-12"></div>--->
	   <div class="row">
           	<div class="col-md-3 col-6 col-sm-3 foot-bar mob-pdb">
        		<div class="col-md-3 col-xs-6">
        			<span class="mob-span-block span-icon">
        			<img src="image/icons1.png" class="img-responsive m-pull-left-none">
        		    </span>
        		</div>
        		<div class="col-md-9 col-xs-6 foot-para">
        		   <p><span>Free Delivery</span>  <br> Full all order 99$ </p>
        		</div>
        	</div>
        	<div class="col-md-3 col-6 col-sm-3 foot-bar mob-pdb">
        		<div class="col-md-3 col-xs-12">
        			<span  class="mob-span-block span-icon">
        			<img src="image/icons2.png" class="img-responsive m-pull-left-none">
        		    </span>
        		</div>
        		<div class="col-md-9 col-xs-12 foot-para ">
        		   <p><span>30 Days Return</span>  <br> If goods have problems  </p>
        		</div>
        	</div>
        	<div class="col-md-3 col-6 col-sm-3 foot-bar mob-pdt">
        		<div class="col-md-3 col-xs-12">
        			<span class="span-icon">
        			<img src="image/icons3.png" class="img-responsive m-pull-left-none">
        		    </span>
        		</div>
        		<div class="col-md-9 col-xs-12 foot-para">
        		   <p><span>Secure Payment</span>  <br> 100% Secure Payment </p>
        		</div>
        	</div>
        	<div class="col-md-3 col-6 col-sm-3 foot-bar mob-pdt">
        		<div class="col-md-3 col-xs-12">
        			<span class="span-icon">
        			<img src="image/icons4.png" class="img-responsive m-pull-left-none">
        		    </span>
        		</div>
        		<div class="col-md-9 col-xs-12 foot-para">
        		   <p><span>24/7 Support</span>  <br> Dedicated support </p>
        		</div>
        	</div>
        </div>
    </div>
</section> 

<footer>
	<div class="container-fluid foot-nav footer-mobile-nav">
		<div class="row">
		 <ul class="heading-nav col-xs-12 footer-mobile-menu"> 
	       	   <li><a href="" style="">ABOUT US</a></li>
	           <li><a href="">CONTACT US</a></li>
	           <li><a href="">HELP</a></li>
	           <li><a href="">GIFT OF VISION</a></li>
	           <li><a href="">OFFERS</a></li>
	           <li><a href="">BLOG</a></li>
	           <li><a href="">CRAZYCASH</a></li>
	           <li><a href="">KNOWLEDGE CENTER</a></li>
	           <li><a href="">CUSTOMER REVIEWS</a></li>
	       </ul>
		</div>
   </div>
	<div class="container-fluid footer-nav">
		<hr>
	</div>
	<div class="container-fluid foot-icon">
		<div class="row">
			<div class="col-md-3 col-xs-12 footer-icon">
			<div class="col-md-12 p_0">
			  <p>Need Helps ? </p>
			</div>
			<div class="col-md-12 p_0">
			       <ul class="heading10"> 
			       	   <li>
			       	   	  <a href="">
			       	   	 	<div>
                            <i class="fa fa-question-circle">
                            </i>
                            </div>	
			       	        <div class="icon"> <span style="text-align: center;"> FAQ </span></div>
			       	      </a>
			       	    </li>
			           <li>
			           	<a href="">
                         
                           <div>
                            <i class="fa fa-envelope">
                            </i>
                            </div>	
			       	        <div class="icon"> <span style="text-align: center;"> EMAIL </span></div>

			           </a></li>
			           <li><a href="">
                          <div>
                            <i class="fa fa-phone">
                            </i>
                            </div>	
			       	        <div class="icon"> <span style="text-align: center;"> PHONE </span></div>

			           </a></li>
			       </ul>
			</div>
			<div class="col-md-12 col-sm-12 footer-carr">
			  <p>We are here for you..</p>
			</div>
			<div class="foot-con">
				<ul class="heading1"> 
		       	   <li><a href="#"><i class="fa fa-envelope" > </i> csc@crazyspects.com </a></li>
		           <li><a href="#"><i class="fa fa-phone" ></i> 033-25480296 / 07980460867  </a></li>
		           <li><a href="#"><i class="fa fa-clock-o"></i> 10:00AM to 7:00PM </a></li>
	           </ul>
			</div>
		</div>
		<div class="col-md-9 col-xs-6 foot-menu">
		<div class="col-md-3 col-xs-6 col-sm-6 footer-menu">
			<div onclick="datatoggle('footernav1')" class="col-md-12 col-sm-6 heading-menu">
			  <p id="button">Eyeglasses </p>
			</div>
			<div class="col-md-12 foot-cat">
			<ul id="footernav1" class=" new heading1"> 
	       	   <li><a href="">Eyeglasses</a></li>
	           <li><a href="">Man Eyeglasses</a></li>
	           <li><a href="">woman Eyeglasses</a></li>
	           <li><a href="">Kids Eyeglasses</a></li>
	           <li><a href="">Computer Eyeglasses</a></li>
	           <li><a href="">Pellucied  Blue Leanses</a></li>
	           <li><a href="">Round</a></li>
	           <li><a href="">Cat eva <br><u> more(+)</u></a></li>
	           
	       </ul>
	       </div>
		</div>
		<div class="col-md-3 col-xs-6 col-sm-6  footer-menu" >
			<div  onclick="datatoggle('effect')"class="col-md-12 col-sm-6  heading-menu">
			  <p id="button">Sunglasses </p>
			</div>
			<div class="col-md-12 foot-cat">
			<ul id="effect" class="new heading1"> 
	       	   <li><a href="">Sunglasses</a></li>
	           <li><a href="">Man Sunglasses</a></li>
	           <li><a href="">woman Sunglasses</a></li>
	           <li><a href="">Kids Sunglasses</a></li>
	           <li><a href="">Clubmaster</a></li>
	           <li><a href="">Cat Eye</a></li>
	           <li><a href="">Wraparound</a></li>
	           <li><a href="">Butterflv <br><u> more(+)</u></a></li>
	           
	       </ul>
	       </div>
		</div>
		<div class="col-md-2 col-xs-6 col-sm-6  footer-menu" >
			<div onclick="datatoggle('effect-1')"class="col-md-12 col-sm-6  heading-menu">
			  <p id="button">Collections </p>
			</div>
			<div class="col-md-12 foot-cat">
			<ul id="effect-1" class="new heading1" > 
	       	   <li><a href="">Collections</a></li>
	           <li><a href="">JRS</a></li>
	           <li><a href="">JRS Pro</a></li>
	           <li><a href="">JRS First</a></li>
	           <li><a href="">XSTYL</a></li>
	           <li><a href="">Graviate First</a></li>
	           <li><a href="">Graviate</a></li>
	           <li><a href="">XSTYL First<br><u> more(+)</u></a></li>
	           
	       </ul>
	       </div>
		</div>
		<div class="col-md-4 col-xs-6 col-sm-6  footer-menu" >
			<div onclick="datatoggle('effect-2')"class="col-md-12 col-sm-6 heading-menu">
			  <p id="button">Presciption Sunglasses </p>
			</div>
			<div class="col-md-12 foot-cat">
			<ul id="effect-2" class="new heading1"> 
	       	   <li><a href="#">Presciption Sunglasses</a></li>
	           <li><a href="">Men Presciption Sunglasses</a></li>
	           <li><a href="">woman Presciption Sunglasses</a></li>
	           <li><a href="">Pilot</a></li>
	           <li><a href="">Retro</a></li>
	           <li><a href="">Retro</a></li>
	           <li><a href="">Round</a></li>
	           	           
	       </ul>
	       </div>
		</div>
	</div>
	</div>
</div>
<div class="container-fluid footer-color">
	<div class="row">
		<div class="col-md-3 col-sm-3 foot-last">
			<p>Copyright @ 2019 . All Rights Reserved </p>
		</div>
		<div class="col-md-7 col-sm-6 footlast-nav">
			 <ul class="heading111"> 
	       	   <li><a href="">CANCELLATION & REFUND POLICY<span>l</span></a></li>
	           <li><a href="">TERMS OF USE<span>l</span></a></li>
	           <li><a href="">PRIVACY POLICY<span>l</span></a></li>
	           <li><a href="">DELIVERY AND SHIPPING TERMS <span>l</span></a></li>
	           <li ><a href="">SITEMAP</a></li>
	       </ul>
		</div>
		<div class="col-md-2  col-xs-12 col-sm-3 footlast-icon">
			<p>follow Us:  <i class="fa fa-facebook-square"></i>  
                           <i class="fa fa-twitter-square"></i>
                           <i class="fa fa-pinterest-square"></i>
                           <i class="fa fa-instagram"></i>
                           <i class="fa fa-youtube-square"></i>



			  </p>
		</div>
		<div class="col-md-3 col-sm-3 moblile-last">
			<p>Copyright @ 2019 . All Rights Reserved </p>
		</div>
	</div>
</div>
</footer>