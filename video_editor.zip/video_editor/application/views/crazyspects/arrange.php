
            <div class="container-fluid">


                <!-- ============================================================== -->
                <!-- PRODUCTS YEARLY SALES -->
                <!-- ============================================================== -->

                <style type="text/css">
                    
                </style>
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="white-box">
                            <h3 class="box-title">Arrange</h3>

                            
                            <div class="drag-container">
                                <ul class="drag-list">
                                    <li class="drag-column drag-column-on-hold">
                                      
                                            
                                        <div class="drag-options" id="options1"></div>
                                        
                                        <ul class="drag-inner-list" id="1">
                                            <li class="drag-item">
                                                <img class="arrange-pic" src="https://www.adorama.com/alc/wp-content/uploads/2018/11/landscape-photography-tips-yosemite-valley-feature.jpg">
                                            </li>
                                            <li class="drag-item">
                                                <img class="arrange-pic" src="https://web-dev.imgix.net/image/admin/ACrLFM1rLlaY2fzUTeXl.jpg?fit=crop&h=64&w=64&auto=format&dpr=1&q=75">
                                            </li>
                                            <li class="drag-item">
                                                <img class="arrange-pic" src="https://iso.500px.com/wp-content/uploads/2014/07/big-one.jpg">
                                            </li>
                                            <li class="drag-item">
                                                <img class="arrange-pic" src="https://media-exp1.licdn.com/dms/image/C4D1BAQFsdjpzrtQWUA/company-background_10000/0/1519796755846?e=2159024400&v=beta&t=tL2HSXGgliQAAqXK0ZvfDvXvdRD2j3Gpk_juoBRmYlM">
                                            </li>
                                            <li class="drag-item">
                                                <img class="arrange-pic" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBhMe8nsQ4MxEC33MLRDL11BO9moA9PS1lFG8OidfHCafSs0uZcShUhMyhi3wiiI6WbyE&usqp=CAU">
                                            </li>
                                        </ul>
                                    </li>






                    </div>
                     <a href="trim.html">
                                        <button class="btn btn-success text-white btn" type="button">
                                              Next - Trim  
                                        </button>
                                    </a>

                </div>
                <!-- ============================================================== -->
                <!-- RECENT SALES -->
                <!-- ============================================================== -->
                
                    <!-- /.col -->
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            