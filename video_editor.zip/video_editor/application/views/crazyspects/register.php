  <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
                <div class="col-lg-12 login-key">
                    <i class="fa fa-key" aria-hidden="true"></i>
                </div>
                <div class="col-lg-12 login-title">
                    Register
                </div>

                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form id="register-form" onsubmit="return submit_form()">
                            <div class="form-group">
                                <label class="form-control-label">Name</label>
                                <input type="text" required="" class="form-control" name="name">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">Phone</label>
                                <input type="text" required="" class="form-control" name="phone">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">Email</label>
                                <input type="email" required="" class="form-control" name="email">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">PASSWORD</label>
                                <input type="password" required="" name="password" class="form-control" i>
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">Confirm PASSWORD</label>
                                <input type="password" required="" name="confirm_password" class="form-control" i>
                            </div>
                             <h4 class="login-new-user-click">
                                <a href="<?php echo base_url('home') ?>">Click Here to Sign In</a>
                             </h4>
                             <span id="from-error">
                               
                             </span>
                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-12 login-btm login-button">
                                    <button type="submit" class="btn btn-outline-primary">LOGIN</button>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2"></div>
            </div>
        </div>
      <script>
         function submit_form(){
          $('.login-button').html('<button type="button" class="btn btn-outline-primary"><i class="fas fa-spinner fa-pulse"></i></button>');
          var form=jQuery("#register-form")[0];
        var formdata1=new FormData(form);
     //   jQuery(form).trigger("reset");
        jQuery.ajax({
       url:'<?php echo base_url('home/sign_up') ?>',
       type:'post',
       data:formdata1,
       contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
           processData: false,
     success:function(result){
      $('.login-button').html('<button type="submit" class="btn btn-outline-primary">LOGIN</button>');
      var obj=JSON.parse(result);
      if(obj.status==1){
          jQuery(form).trigger("reset");
          $('#from-error').html('<p style="color:green">'+obj.err+'</p>');
          setTimeout(function() { 
              window.location.href='<?php echo base_url('home') ?>'}, 3000);
      }else{
         $('#from-error').html('<p style="color:red">'+obj.err+'</p>'); 
      }
     }
     }); 
     return false;  
     }  
      </script>
  </body>
</html>