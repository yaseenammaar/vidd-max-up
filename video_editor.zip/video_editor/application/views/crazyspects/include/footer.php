<footer class="footer text-center">  <a href="<?php echo base_url() ?>"></a>
</footer>